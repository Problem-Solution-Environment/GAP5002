#include "Player.h"



Player::Player(char* img) : AWSprite(img,1,1)
{
	set_world_position(100, 100);
	set_transparent_colour(0, 0, 0);
	//set_auto_animate(100);
	setSpeed(20);
	setHealth(100);
	setState(STATE_NOTMOVING)
}

Player::~Player()
{
}














