#pragma once
#include "AWSprite.h"
#include "GameBase.h"



enum State
{
	STATE_NOTMOVING, //When Not Moving
	STATE_MOVING, //When any key is pressed (some kind of movement)
	STATE_w,
	STATE_a,
	STATE_s,
	STATE_d,
	STATE_wd, //Up-Right
	STATE_ds, //Down-Right
	STATE_sa, //Down-Left
	STATE_aw  //Up-Left
};

class Player : public AWSprite 
{
	unsigned int m_speed; 
	unsigned int m_health;
	bool m_canBeDamaged;
	State m_currentState; 
	
public:
	Player(char*img);
	~Player();
	unsigned int getSpeed() { return m_speed; }
	void setSpeed(unsigned int newSpeed){ m_speed = newSpeed; }
	unsigned int getHealth() { return m_health; }
	void setHealth(unsigned int newHealth){ m_health = newHealth; }
	State getState() { return m_currentState; }
	void setState(State newState) { m_currentState = newState; }

};

