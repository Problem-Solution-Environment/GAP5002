#include "Game.h"


Game::Game()
{
}


Game::~Game()
{
	SAFE_DELETE_PTR(m_player);
}


void Game::setup()
{
	setBackground("images/sBgrd1.png");
	m_player = new Player("images/test3.png");
	
	
}

void Game::logic()
{
	playerMovement();
}

void Game::draw()
{
	m_player->update_everything();


}




void Game::playerMovement()
{
	switch (m_player->getState()) //Using the players current state (default to STATE_NOTMOVING)
	{
	case STATE_NOTMOVING:
		cout << ("\nNow in STATE_NOTMOVING");
		m_player->set_velocities(0, 0); 
		m_player->set_auto_move(0);
		cout << ("\nno movement applied");
		if (keyDown == SDLK_w) //Checking for the four movement inputs 
		{
			cout << ("\nw key down");
			m_player->setState(STATE_w); //Setting the appropriate state
			cout << m_player->getState();
		}
		if (keyDown == SDLK_s)
		{
			cout << ("\ns key down");
			m_player->setState(STATE_s);
			cout << m_player->getState();
		}
		if (keyDown == SDLK_a)
		{
			cout << ("\na key down");
			m_player->setState(STATE_a);
			cout << m_player->getState();
		}
	    if (keyDown == SDLK_d)
		{
			cout << ("\nd key down");
			m_player->setState(STATE_d);
			cout << m_player->getState(); 
		}
		break;

	case STATE_w:
		if (keyDown == SDLK_a) //Checking for extra inputs for diagonal movement
		{
			m_player->setState(STATE_aw);
		}
		else if (keyDown == SDLK_d)
		{
			m_player->setState(STATE_wd);
		}
		else //No extra inputs so just the normal movement
		{
			cout << ("\nNow in STATE_W");
			m_player->set_velocities(m_player->get_x_velocity(), -10);
			m_player->set_auto_move(m_player->getSpeed());
			cout << ("\nMovement applied");
		}
		if (keyUp == SDLK_w) 
		{
			m_player->setState(STATE_NOTMOVING);
		}
		break;

	case STATE_s:
		if (keyDown == SDLK_a)
		{
			m_player->setState(STATE_sa);
		}
		else if (keyDown == SDLK_d)
		{
			m_player->setState(STATE_ds);
		}
		else
		{
			cout << ("\nNow in STATE_S");
			m_player->set_velocities(m_player->get_x_velocity(), +10);
			m_player->set_auto_move(m_player->getSpeed());
			cout << ("\nMovement applied");
		}
		if (keyUp == SDLK_s)
		{
			m_player->setState(STATE_NOTMOVING);
		}
		break;

	case STATE_a:
		if (keyDown == SDLK_w)
		{
			m_player->setState(STATE_aw);
		}
		else if (keyDown == SDLK_s)
		{
			m_player->setState(STATE_sa);
		}
		else {
			cout << ("\nNow in STATE_A");
			m_player->set_velocities(-10, m_player->get_y_velocity());
			m_player->set_auto_move(m_player->getSpeed());
			cout << ("\nMovement applied");
		}
		if (keyUp == SDLK_a)
		{
			m_player->setState(STATE_NOTMOVING);
		}
		break;

	case STATE_d:
		if (keyDown == SDLK_w)
		{
			m_player->setState(STATE_wd);
		}
		else if (keyDown == SDLK_s)
		{
			m_player->setState(STATE_ds);
		}
		else {
			cout << ("\nNow in STATE_D");
			m_player->set_velocities(+10, m_player->get_y_velocity());
			m_player->set_auto_move(m_player->getSpeed());
			cout << ("\nMovement applied");
		}
		if (keyUp == SDLK_d)
		{
			m_player->setState(STATE_NOTMOVING);
		}
		break;

	case STATE_wd:
		cout << ("\nNow in STATE_WD");
		m_player->set_velocities(+10, -10);
		m_player->set_auto_move(m_player->getSpeed());
			if (keyUp == SDLK_d)
			{
				m_player->setState(STATE_w);
			}
			else if (keyUp == SDLK_w)
			{
				m_player->setState(STATE_d);
			}
		break;

	case STATE_ds:
		cout << ("\nNow in STATE_DS");
		m_player->set_velocities(+10, +10);
		m_player->set_auto_move(m_player->getSpeed());
		if (keyUp == SDLK_d)
		{
			m_player->setState(STATE_s);
		}
		else if (keyUp == SDLK_s)
		{
			m_player->setState(STATE_d);
		}
		break;

	case STATE_sa:
		cout << ("\nNow in STATE_SA");
		m_player->set_velocities(-10, +10);
		m_player->set_auto_move(m_player->getSpeed());
		if (keyUp == SDLK_s)
		{
			m_player->setState(STATE_a);
		}
		else if (keyUp == SDLK_a)
		{
			m_player->setState(STATE_s);
		}
		break;

	case STATE_aw:
		cout << ("\nNow in STATE_AW");
		m_player->set_velocities(-10, -10);
		m_player->set_auto_move(m_player->getSpeed());
		if (keyUp == SDLK_a)
		{
			m_player->setState(STATE_w);
		}
		else if (keyUp == SDLK_w)
		{
			m_player->setState(STATE_a);
		}
		break;
	}
}
