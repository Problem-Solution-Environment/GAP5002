#pragma once

#include "GameBase.h"
#include "Player.h"

class Game : public GameBase
{
	Player *m_player;
	
	
public:
	Game();
	~Game();
	void setup();
	void logic();
	void draw();
	void playerMovement();
};

